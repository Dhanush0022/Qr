# QR Code Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/gOJvjqG](https://codepen.io/icomgroup/pen/gOJvjqG).

